"""
Phase 403: AI Inference Engine for Real-time Drone Decision Making
"""

import threading
import time
from collections import deque
from dataclasses import dataclass, field
from enum import Enum
from typing import Any

import numpy as np


class InferenceModel(Enum):
    """``InferenceModel`` 관련 기능을 제공한다."""
    LIGHTGBM = "lightgbm"
    XGBOOST = "xgboost"
    ONNX = "onnx"
    TENSORRT = "tensorrt"
    LSTM = "lstm"
    TRANSFORMER = "transformer"


class InferenceTask(Enum):
    """``InferenceTask`` 관련 기능을 제공한다."""
    COLLISION_PREDICTION = "collision_prediction"
    TRAJECTORY_PREDICTION = "trajectory_prediction"
    ANOMALY_DETECTION = "anomaly_detection"
    PATH_OPTIMIZATION = "path_optimization"
    WEATHER_ESTIMATION = "weather_estimation"
    BATTERY_PREDICTION = "battery_prediction"


@dataclass
class InferenceRequest:
    """``InferenceRequest`` 데이터를 표현한다."""
    task: InferenceTask
    inputs: dict[str, np.ndarray]
    priority: int = 5
    timestamp: float = field(default_factory=time.time)
    deadline: float | None = None


@dataclass
class InferenceResult:
    """``InferenceResult`` 데이터를 표현한다."""
    task: InferenceTask
    outputs: dict[str, np.ndarray]
    latency_ms: float
    confidence: float
    timestamp: float


@dataclass
class ModelMetadata:
    """``ModelMetadata`` 관련 기능을 제공한다."""
    name: str
    model_type: InferenceModel
    input_shapes: dict[str, tuple[int, ...]]
    output_shapes: dict[str, tuple[int, ...]]
    loaded_at: float = field(default_factory=time.time)
    inference_count: int = 0
    total_inference_time: float = 0.0


class AIInferenceEngine:
    """``AIInferenceEngine`` 역할을 담당한다."""
    def __init__(
        self,
        max_queue_size: int = 1000,
        num_workers: int = 4,
        enable_batch_inference: bool = True,
        batch_timeout_ms: float = 10.0,
    ):
        """인스턴스를 초기화한다."""
        self.max_queue_size = max_queue_size
        self.num_workers = num_workers
        self.enable_batch_inference = enable_batch_inference
        self.batch_timeout_ms = batch_timeout_ms

        self.models: dict[str, ModelMetadata] = {}
        self.inference_queues: dict[InferenceTask, deque] = {
            task: deque(maxlen=max_queue_size) for task in InferenceTask
        }
        self.results: dict[str, deque] = {}

        self.is_running = False
        self.worker_threads: list[threading.Thread] = []

        self.metrics = {
            "total_requests": 0,
            "total_results": 0,
            "avg_latency_ms": 0.0,
            "queue_overflows": 0,
        }

    def load_model(
        self,
        model_name: str,
        model_type: InferenceModel,
        model_path: str,
        input_shapes: dict[str, tuple[int, ...]],
        output_shapes: dict[str, tuple[int, ...]],
    ):
        """`model` 정보를 조회한다."""
        metadata = ModelMetadata(
            name=model_name,
            model_type=model_type,
            input_shapes=input_shapes,
            output_shapes=output_shapes,
        )
        self.models[model_name] = metadata
        self.results[model_name] = deque(maxlen=1000)

    def submit_request(self, request: InferenceRequest) -> str:
        """``submit_request`` 동작을 수행한다."""
        request_id = f"{request.task.value}_{int(request.timestamp * 1000)}"

        if len(self.inference_queues[request.task]) >= self.max_queue_size:
            self.metrics["queue_overflows"] += 1
            raise RuntimeError(f"Queue overflow for task {request.task.value}")

        self.inference_queues[request.task].append((request_id, request))
        self.metrics["total_requests"] += 1

        return request_id

    def get_result(
        self, request_id: str, timeout_ms: float = 1000
    ) -> InferenceResult | None:
        """`result` 정보를 조회한다."""
        for _model_name, result_queue in self.results.items():
            for result in result_queue:
                if hasattr(result, "request_id") and result.request_id == request_id:
                    return result

        return None

    def infer(
        self,
        task: InferenceTask,
        inputs: dict[str, np.ndarray],
        model_name: str | None = None,
        priority: int = 5,
    ) -> InferenceResult:
        """``infer`` 동작을 수행한다."""
        start_time = time.time()

        if model_name is None:
            model_name = self._get_default_model(task)

        if model_name not in self.models:
            return InferenceResult(
                task=task,
                outputs={"error": np.array(["Model not found"])},
                latency_ms=(time.time() - start_time) * 1000,
                confidence=0.0,
                timestamp=start_time,
            )

        outputs = self._run_inference(model_name, inputs)

        latency_ms = (time.time() - start_time) * 1000

        if model_name in self.models:
            self.models[model_name].inference_count += 1
            self.models[model_name].total_inference_time += latency_ms

        confidence = self._calculate_confidence(outputs)

        result = InferenceResult(
            task=task,
            outputs=outputs,
            latency_ms=latency_ms,
            confidence=confidence,
            timestamp=start_time,
        )

        self.metrics["total_results"] += 1
        self.metrics["avg_latency_ms"] = (
            self.metrics["avg_latency_ms"] * 0.99 + latency_ms * 0.01
        )

        return result

    def _run_inference(
        self,
        model_name: str,
        inputs: dict[str, np.ndarray],
    ) -> dict[str, np.ndarray]:
        metadata = self.models[model_name]

        if metadata.model_type == InferenceModel.LIGHTGBM:
            return self._infer_lightgbm(metadata, inputs)
        elif metadata.model_type == InferenceModel.XGBOOST:
            return self._infer_xgboost(metadata, inputs)
        elif metadata.model_type == InferenceModel.ONNX:
            return self._infer_onnx(metadata, inputs)
        elif metadata.model_type == InferenceModel.LSTM:
            return self._infer_lstm(metadata, inputs)
        else:
            return self._infer_default(metadata, inputs)

    def _infer_lightgbm(
        self,
        metadata: ModelMetadata,
        inputs: dict[str, np.ndarray],
    ) -> dict[str, np.ndarray]:
        output = {}
        for key, arr in inputs.items():
            output[key] = (
                np.random.rand(*arr.shape[:2])
                if len(arr.shape) > 1
                else np.random.rand(1)
            )
        return output

    def _infer_xgboost(
        self,
        metadata: ModelMetadata,
        inputs: dict[str, np.ndarray],
    ) -> dict[str, np.ndarray]:
        output = {}
        for key, arr in inputs.items():
            output[key] = (
                np.random.rand(*arr.shape[:2])
                if len(arr.shape) > 1
                else np.random.rand(1)
            )
        return output

    def _infer_onnx(
        self,
        metadata: ModelMetadata,
        inputs: dict[str, np.ndarray],
    ) -> dict[str, np.ndarray]:
        output = {}
        for key, arr in inputs.items():
            output[key] = (
                np.random.rand(*arr.shape[:2])
                if len(arr.shape) > 1
                else np.random.rand(1)
            )
        return output

    def _infer_lstm(
        self,
        metadata: ModelMetadata,
        inputs: dict[str, np.ndarray],
    ) -> dict[str, np.ndarray]:
        batch_size = next(iter(inputs.values())).shape[0] if inputs else 1
        output = {
            "prediction": np.random.rand(batch_size, 10),
            "hidden_state": np.random.rand(batch_size, 64),
        }
        return output

    def _infer_default(
        self,
        metadata: ModelMetadata,
        inputs: dict[str, np.ndarray],
    ) -> dict[str, np.ndarray]:
        output = {}
        for key, arr in inputs.items():
            output[key] = (
                np.random.rand(*arr.shape[:2])
                if len(arr.shape) > 1
                else np.random.rand(1)
            )
        return output

    def _get_default_model(self, task: InferenceTask) -> str:
        model_mapping = {
            InferenceTask.COLLISION_PREDICTION: "collision_model",
            InferenceTask.TRAJECTORY_PREDICTION: "trajectory_model",
            InferenceTask.ANOMALY_DETECTION: "anomaly_model",
            InferenceTask.PATH_OPTIMIZATION: "path_model",
            InferenceTask.WEATHER_ESTIMATION: "weather_model",
            InferenceTask.BATTERY_PREDICTION: "battery_model",
        }
        return model_mapping.get(task, "default_model")

    def _calculate_confidence(self, outputs: dict[str, np.ndarray]) -> float:
        if not outputs:
            return 0.0

        confidences = []
        for key, arr in outputs.items():
            if "probability" in key.lower() or "score" in key.lower():
                if len(arr.shape) > 1:
                    max_probs = np.max(arr, axis=-1)
                    confidences.append(np.mean(max_probs))
                else:
                    confidences.append(float(arr[0]) if len(arr) > 0 else 0.0)

        return np.mean(confidences) if confidences else 0.5

    def get_metrics(self) -> dict[str, Any]:
        """`metrics` 정보를 조회한다."""
        model_metrics = {}
        for name, metadata in self.models.items():
            model_metrics[name] = {
                "inference_count": metadata.inference_count,
                "avg_latency_ms": (
                    metadata.total_inference_time / metadata.inference_count
                    if metadata.inference_count > 0
                    else 0
                ),
            }

        return {
            "global": self.metrics,
            "models": model_metrics,
            "queue_sizes": {
                task.value: len(queue) for task, queue in self.inference_queues.items()
            },
        }

    def warm_up(self, task: InferenceTask, num_iterations: int = 10):
        """``warm_up`` 동작을 수행한다."""
        default_inputs = self._generate_dummy_inputs(task)

        for _ in range(num_iterations):
            self.infer(task, default_inputs)

    def _generate_dummy_inputs(self, task: InferenceTask) -> dict[str, np.ndarray]:
        if task == InferenceTask.COLLISION_PREDICTION:
            return {
                "positions": np.random.rand(10, 3),
                "velocities": np.random.rand(10, 3),
            }
        elif task == InferenceTask.TRAJECTORY_PREDICTION:
            return {
                "history": np.random.rand(10, 20, 3),
            }
        else:
            return {"data": np.random.rand(10, 10)}

    def clear_queue(self, task: InferenceTask):
        """`queue` 상태를 정리한다."""
        self.inference_queues[task].clear()

    def reset_metrics(self):
        """`metrics` 상태를 정리한다."""
        self.metrics = {
            "total_requests": 0,
            "total_results": 0,
            "avg_latency_ms": 0.0,
            "queue_overflows": 0,
        }

        for metadata in self.models.values():
            metadata.inference_count = 0
            metadata.total_inference_time = 0.0
