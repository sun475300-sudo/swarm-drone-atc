"""
Phase 474: Autonomous Negotiation Engine
다자간 협상 — 양보 전략, 효용 함수, 합의 도출.
"""

from dataclasses import dataclass, field
from enum import Enum

import numpy as np


class ConcessionStrategy(Enum):
    """``ConcessionStrategy`` 관련 기능을 제공한다."""
    LINEAR = "linear"
    BOULWARE = "boulware"
    CONCEDER = "conceder"
    TOUGHGUY = "toughguy"
    RANDOM = "random"


@dataclass
class NegotiationIssue:
    """``NegotiationIssue`` 관련 기능을 제공한다."""
    name: str
    min_value: float
    max_value: float
    weight: float = 1.0


@dataclass
class Offer:
    """``Offer`` 관련 기능을 제공한다."""
    agent_id: str
    values: dict[str, float]
    utility: float
    round_num: int
    timestamp: float = 0.0


@dataclass
class NegotiationAgent:
    """``NegotiationAgent`` 역할을 담당한다."""
    agent_id: str
    strategy: ConcessionStrategy
    reservation_utility: float = 0.3
    issues: dict[str, tuple[float, float]] = field(default_factory=dict)  # preferred range
    weights: dict[str, float] = field(default_factory=dict)
    offers_made: list[Offer] = field(default_factory=list)
    offers_received: list[Offer] = field(default_factory=list)


class AutonomousNegotiation:
    """Multi-party negotiation engine for drone swarm resource allocation."""

    def __init__(self, seed: int = 42, max_rounds: int = 100, deadline: float = 1.0):
        """인스턴스를 초기화한다."""
        self.rng = np.random.default_rng(seed)
        self.agents: dict[str, NegotiationAgent] = {}
        self.issues: list[NegotiationIssue] = []
        self.max_rounds = max_rounds
        self.deadline = deadline
        self.current_round = 0
        self.agreements: list[dict] = []
        self.history: list[Offer] = []

    def add_issue(self, name: str, min_val: float, max_val: float, weight: float = 1.0) -> None:
        """`issue` 항목을 추가한다."""
        self.issues.append(NegotiationIssue(name, min_val, max_val, weight))

    def add_agent(self, agent_id: str, strategy: ConcessionStrategy,
                  preferences: dict[str, tuple[float, float]] | None = None,
                  reservation: float = 0.3) -> NegotiationAgent:
        """`agent` 항목을 추가한다."""
        prefs = preferences or {}
        weights = {issue.name: issue.weight + self.rng.standard_normal() * 0.1
                   for issue in self.issues}
        agent = NegotiationAgent(agent_id, strategy, reservation, prefs, weights)
        self.agents[agent_id] = agent
        return agent

    def _compute_utility(self, agent: NegotiationAgent, values: dict[str, float]) -> float:
        utility = 0.0
        total_weight = sum(agent.weights.values()) or 1.0
        for issue in self.issues:
            v = values.get(issue.name, issue.min_value)
            normalized = (v - issue.min_value) / max(issue.max_value - issue.min_value, 1e-10)
            pref = agent.issues.get(issue.name)
            if pref:
                dist = abs(v - (pref[0] + pref[1]) / 2) / max(issue.max_value - issue.min_value, 1e-10)
                normalized = max(0, 1 - dist)
            utility += agent.weights.get(issue.name, 1.0) * normalized
        return utility / total_weight

    def _concession_factor(self, strategy: ConcessionStrategy, t: float) -> float:
        t = min(t, 1.0)
        if strategy == ConcessionStrategy.LINEAR:
            return t
        elif strategy == ConcessionStrategy.BOULWARE:
            return t ** 3
        elif strategy == ConcessionStrategy.CONCEDER:
            return 1 - (1 - t) ** 3
        elif strategy == ConcessionStrategy.TOUGHGUY:
            return t ** 5
        else:
            return self.rng.random() * t

    def _generate_offer(self, agent: NegotiationAgent) -> Offer:
        t = self.current_round / self.max_rounds
        cf = self._concession_factor(agent.strategy, t)

        values = {}
        for issue in self.issues:
            pref = agent.issues.get(issue.name)
            ideal = (pref[0] + pref[1]) / 2 if pref else (issue.max_value + issue.min_value) / 2
            midpoint = (issue.max_value + issue.min_value) / 2
            value = ideal + cf * (midpoint - ideal)
            value += self.rng.standard_normal() * (issue.max_value - issue.min_value) * 0.02
            value = np.clip(value, issue.min_value, issue.max_value)
            values[issue.name] = float(value)

        utility = self._compute_utility(agent, values)
        return Offer(agent.agent_id, values, utility, self.current_round)

    def _evaluate_offer(self, agent: NegotiationAgent, offer: Offer) -> bool:
        utility = self._compute_utility(agent, offer.values)
        t = self.current_round / self.max_rounds
        threshold = agent.reservation_utility + (1 - agent.reservation_utility) * (1 - t)
        return utility >= threshold

    def negotiate_round(self) -> dict | None:
        """``negotiate_round`` 동작을 수행한다."""
        self.current_round += 1
        agent_ids = list(self.agents.keys())
        offers = {}

        for aid in agent_ids:
            offer = self._generate_offer(self.agents[aid])
            offers[aid] = offer
            self.agents[aid].offers_made.append(offer)
            self.history.append(offer)

        for i, a_id in enumerate(agent_ids):
            for j, b_id in enumerate(agent_ids):
                if i >= j:
                    continue
                offer_a = offers[a_id]
                offer_b = offers[b_id]

                a_accepts = self._evaluate_offer(self.agents[a_id], offer_b)
                b_accepts = self._evaluate_offer(self.agents[b_id], offer_a)

                if a_accepts and b_accepts:
                    merged = {}
                    for issue in self.issues:
                        merged[issue.name] = (offer_a.values[issue.name] + offer_b.values[issue.name]) / 2
                    agreement = {
                        "parties": [a_id, b_id],
                        "values": merged,
                        "round": self.current_round,
                        "utility_a": self._compute_utility(self.agents[a_id], merged),
                        "utility_b": self._compute_utility(self.agents[b_id], merged),
                    }
                    self.agreements.append(agreement)
                    return agreement
        return None

    def run(self) -> dict | None:
        """메인 실행 루프를 수행한다."""
        for _ in range(self.max_rounds):
            result = self.negotiate_round()
            if result:
                return result
        return None

    def summary(self) -> dict:
        """현재 상태 요약을 반환한다."""
        return {
            "agents": len(self.agents),
            "issues": len(self.issues),
            "rounds": self.current_round,
            "agreements": len(self.agreements),
            "total_offers": len(self.history),
        }
