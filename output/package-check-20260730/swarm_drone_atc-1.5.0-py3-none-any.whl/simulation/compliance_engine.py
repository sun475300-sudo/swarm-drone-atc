"""Compliance engine for Phase 172.

Executes rule sets against flight snapshots and generates violation reports.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class ComplianceRule:
    """``ComplianceRule`` 관련 기능을 제공한다."""
    name: str
    metric: str
    min_value: float | None = None
    max_value: float | None = None
    severity: str = "MEDIUM"
    description: str = ""


@dataclass(frozen=True)
class ComplianceViolation:
    """``ComplianceViolation`` 관련 기능을 제공한다."""
    rule_name: str
    drone_id: str
    metric: str
    actual_value: float
    min_value: float | None
    max_value: float | None
    severity: str
    message: str
    eval_index: int = 0


DEFAULT_RULESET: list[ComplianceRule] = [
    ComplianceRule("MAX_ALT", "altitude_m", max_value=120.0, severity="HIGH", description="K-UTM max altitude"),
    ComplianceRule("MIN_ALT", "altitude_m", min_value=30.0, severity="MEDIUM", description="Minimum safe altitude"),
    ComplianceRule("MAX_SPEED", "speed_mps", max_value=25.0, severity="MEDIUM", description="Speed limit"),
    ComplianceRule("MIN_BATTERY", "battery_pct", min_value=10.0, severity="HIGH", description="Battery safety floor"),
]


class ComplianceEngine:
    """``ComplianceEngine`` 역할을 담당한다."""
    def __init__(self, ruleset: list[ComplianceRule] | None = None) -> None:
        """인스턴스를 초기화한다."""
        self._ruleset = list(ruleset or DEFAULT_RULESET)
        self._violations: list[ComplianceViolation] = []
        self._evaluations = 0

    @property
    def ruleset(self) -> list[ComplianceRule]:
        """``ruleset`` 동작을 수행한다."""
        return list(self._ruleset)

    def register_ruleset(self, ruleset: list[ComplianceRule]) -> None:
        """`ruleset` 항목을 추가한다."""
        self._ruleset = list(ruleset)

    def _check_rule(
        self,
        drone_id: str,
        rule: ComplianceRule,
        metrics: dict[str, float],
        eval_index: int,
    ) -> ComplianceViolation | None:
        if rule.metric not in metrics:
            return None

        value = float(metrics[rule.metric])
        violated = False
        reason = ""
        if rule.max_value is not None and value > rule.max_value:
            violated = True
            reason = f"{value:.2f} > {rule.max_value:.2f}"
        if rule.min_value is not None and value < rule.min_value:
            violated = True
            reason = f"{value:.2f} < {rule.min_value:.2f}"

        if not violated:
            return None

        return ComplianceViolation(
            rule_name=rule.name,
            drone_id=drone_id,
            metric=rule.metric,
            actual_value=value,
            min_value=rule.min_value,
            max_value=rule.max_value,
            severity=rule.severity,
            message=f"{rule.name} violation: {reason}",
            eval_index=eval_index,
        )

    def evaluate_flight(self, drone_id: str, **metrics: float) -> list[ComplianceViolation]:
        """`flight` 결과를 계산하거나 판정한다."""
        self._evaluations += 1
        out: list[ComplianceViolation] = []
        for rule in self._ruleset:
            v = self._check_rule(
                drone_id=drone_id,
                rule=rule,
                metrics=metrics,
                eval_index=self._evaluations,
            )
            if v is not None:
                out.append(v)
                self._violations.append(v)
        return out

    def rule_hotspots(self, top_n: int = 3) -> list[dict[str, Any]]:
        """``rule_hotspots`` 동작을 수행한다."""
        by_rule: dict[str, int] = {}
        by_severity: dict[str, str] = {}
        for v in self._violations:
            by_rule[v.rule_name] = by_rule.get(v.rule_name, 0) + 1
            by_severity[v.rule_name] = v.severity
        ranked = sorted(by_rule.items(), key=lambda kv: (-kv[1], kv[0]))
        out: list[dict[str, Any]] = []
        for name, count in ranked[: max(1, int(top_n))]:
            out.append(
                {
                    "rule": name,
                    "count": count,
                    "severity": by_severity.get(name, "UNKNOWN"),
                }
            )
        return out

    def severity_trend(self, window: int = 5) -> list[dict[str, Any]]:
        """``severity_trend`` 동작을 수행한다."""
        size = max(1, int(window))
        if self._evaluations == 0:
            return []
        buckets: list[dict[str, Any]] = []
        start = 1
        while start <= self._evaluations:
            end = min(self._evaluations, start + size - 1)
            counts: dict[str, int] = {}
            total = 0
            for v in self._violations:
                if start <= v.eval_index <= end:
                    counts[v.severity] = counts.get(v.severity, 0) + 1
                    total += 1
            buckets.append(
                {
                    "start_eval": start,
                    "end_eval": end,
                    "violations": total,
                    "by_severity": counts,
                }
            )
            start = end + 1
        return buckets

    def evaluate_batch(self, snapshots: list[dict[str, Any]]) -> dict[str, list[ComplianceViolation]]:
        """`batch` 결과를 계산하거나 판정한다."""
        by_drone: dict[str, list[ComplianceViolation]] = {}
        for item in snapshots:
            drone_id = str(item.get("drone_id", "UNKNOWN"))
            metrics = {k: v for k, v in item.items() if k != "drone_id"}
            violations = self.evaluate_flight(drone_id, **metrics)
            by_drone[drone_id] = violations
        return by_drone

    def violation_report(self) -> dict[str, Any]:
        """``violation_report`` 동작을 수행한다."""
        by_severity: dict[str, int] = {}
        by_rule: dict[str, int] = {}
        for v in self._violations:
            by_severity[v.severity] = by_severity.get(v.severity, 0) + 1
            by_rule[v.rule_name] = by_rule.get(v.rule_name, 0) + 1
        return {
            "total_violations": len(self._violations),
            "by_severity": by_severity,
            "by_rule": by_rule,
        }

    def summary(self) -> dict[str, Any]:
        """현재 상태 요약을 반환한다."""
        report = self.violation_report()
        hotspots = self.rule_hotspots(top_n=3)
        return {
            "rules": len(self._ruleset),
            "evaluations": self._evaluations,
            "total_violations": report["total_violations"],
            "hotspots": hotspots,
        }

    def clear(self) -> None:
        """`대상` 상태를 정리한다."""
        self._violations.clear()
        self._evaluations = 0
