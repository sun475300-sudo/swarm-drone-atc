"""
Phase 449: Data Encryption System for Secure Storage
"""

import hashlib
import time
from dataclasses import dataclass


@dataclass
class EncryptedData:
    """``EncryptedData`` 관련 기능을 제공한다."""
    data_id: str
    encrypted_content: bytes
    key_id: str
    timestamp: float


class DataEncryptionSystem:
    """``DataEncryptionSystem`` 역할을 담당한다."""
    def __init__(self):
        """인스턴스를 초기화한다."""
        self.keys: dict[str, bytes] = {}
        self.encrypted_data: dict[str, EncryptedData] = {}

    def generate_key(self, key_id: str) -> bytes:
        """`key` 결과를 생성한다."""
        key = hashlib.sha256(f"{key_id}{time.time()}".encode()).digest()
        self.keys[key_id] = key
        return key

    def encrypt(self, data_id: str, content: bytes, key_id: str) -> EncryptedData:
        """``encrypt`` 동작을 수행한다."""
        if key_id not in self.keys:
            self.generate_key(key_id)

        key = self.keys[key_id]
        encrypted = bytes(
            a ^ b for a, b in zip(content, key * (len(content) // len(key) + 1), strict=False)
        )

        enc_data = EncryptedData(data_id, encrypted, key_id, time.time())
        self.encrypted_data[data_id] = enc_data

        return enc_data

    def decrypt(self, data_id: str) -> bytes:
        """``decrypt`` 동작을 수행한다."""
        if data_id not in self.encrypted_data:
            return b""

        enc = self.encrypted_data[data_id]
        key = self.keys[enc.key_id]

        decrypted = bytes(
            a ^ b
            for a, b in zip(
                enc.encrypted_content,
                key * (len(enc.encrypted_content) // len(key) + 1), strict=False,
            )
        )

        return decrypted

    def rotate_key(self, old_key_id: str, new_key_id: str) -> bool:
        """``rotate_key`` 동작을 수행한다."""
        if old_key_id not in self.keys:
            return False

        self.keys[old_key_id]

        for data_id, enc in self.encrypted_data.items():
            if enc.key_id == old_key_id:
                decrypted = self.decrypt(data_id)
                self.encrypt(data_id, decrypted, new_key_id)

        del self.keys[old_key_id]
        return True
