"""
Multi-model ensemble predictor.
===============================
Combines model outputs through adaptive weighted averaging.
"""
from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass
from typing import Any


@dataclass
class EnsembleModel:
    """``EnsembleModel`` 관련 기능을 제공한다."""
    name: str
    predict_fn: Callable[[list[float]], float]
    weight: float = 1.0
    mae: float = 1.0


class EnsemblePredictor:
    """``EnsemblePredictor`` 관련 기능을 제공한다."""
    def __init__(self) -> None:
        """인스턴스를 초기화한다."""
        self._models: dict[str, EnsembleModel] = {}
        self._predictions = 0

    def register_model(
        self,
        name: str,
        predict_fn: Callable[[list[float]], float],
        weight: float = 1.0,
    ) -> None:
        """`model` 항목을 추가한다."""
        self._models[name] = EnsembleModel(
            name=name,
            predict_fn=predict_fn,
            weight=max(float(weight), 1e-6),
        )

    def _normalized_weights(self) -> dict[str, float]:
        if not self._models:
            return {}
        total = sum(m.weight for m in self._models.values())
        if total <= 0:
            return {n: 1.0 / len(self._models) for n in self._models}
        return {n: m.weight / total for n, m in self._models.items()}

    def predict(self, features: list[float]) -> dict[str, Any]:
        """`대상` 결과를 계산하거나 판정한다."""
        if not self._models:
            return {"prediction": 0.0, "components": {}}

        weights = self._normalized_weights()
        components: dict[str, float] = {}
        total = 0.0
        for name, model in self._models.items():
            pred = float(model.predict_fn(features))
            components[name] = round(pred, 6)
            total += pred * weights[name]

        self._predictions += 1
        return {
            "prediction": round(total, 6),
            "components": components,
            "weights": {k: round(v, 6) for k, v in weights.items()},
        }

    def calibrate(self, validation_data: list[tuple[list[float], float]]) -> dict[str, float]:
        """``calibrate`` 동작을 수행한다."""
        if not self._models or not validation_data:
            return {}

        errors: dict[str, list[float]] = {name: [] for name in self._models}
        for features, target in validation_data:
            for name, model in self._models.items():
                pred = float(model.predict_fn(features))
                errors[name].append(abs(pred - float(target)))

        for name, vals in errors.items():
            mae = sum(vals) / max(len(vals), 1)
            self._models[name].mae = mae
            self._models[name].weight = 1.0 / max(mae, 1e-3)

        return {name: round(model.weight, 6) for name, model in self._models.items()}

    def top_model(self) -> str | None:
        """``top_model`` 동작을 수행한다."""
        if not self._models:
            return None
        return max(self._models.values(), key=lambda m: m.weight).name

    def summary(self) -> dict[str, Any]:
        """현재 상태 요약을 반환한다."""
        return {
            "models": len(self._models),
            "predictions": self._predictions,
            "top_model": self.top_model(),
        }
