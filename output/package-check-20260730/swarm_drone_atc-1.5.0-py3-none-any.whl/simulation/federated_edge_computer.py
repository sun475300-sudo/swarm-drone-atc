"""
Phase 419: Federated Edge Computer for Distributed Inference
"""

from dataclasses import dataclass
from enum import Enum
from typing import Any

import numpy as np


class EdgeDeviceType(Enum):
    """``EdgeDeviceType`` 관련 기능을 제공한다."""
    DRONE = "drone"
    EDGE_SERVER = "edge_server"
    GATEWAY = "gateway"


@dataclass
class EdgeDevice:
    """``EdgeDevice`` 관련 기능을 제공한다."""
    device_id: str
    device_type: EdgeDeviceType
    compute_capacity: float
    memory_mb: float
    battery_level: float
    is_online: bool


@dataclass
class InferenceTask:
    """``InferenceTask`` 관련 기능을 제공한다."""
    task_id: str
    model_name: str
    input_data: np.ndarray
    priority: int
    deadline: float


class FederatedEdgeComputer:
    """``FederatedEdgeComputer`` 관련 기능을 제공한다."""
    def __init__(
        self,
        federation_id: str,
        load_balancing: str = "memory_based",
    ):
        """인스턴스를 초기화한다."""
        self.federation_id = federation_id
        self.load_balancing = load_balancing

        self.devices: dict[str, EdgeDevice] = {}
        self.task_queue: list[InferenceTask] = []
        self.active_tasks: dict[str, str] = {}

        self._initialize_devices()

    def _initialize_devices(self):
        for i in range(10):
            device_id = f"drone_{i}"
            self.register_device(
                device_id=device_id,
                device_type=EdgeDeviceType.DRONE,
                compute_capacity=np.random.uniform(1, 5),
                memory_mb=np.random.uniform(512, 2048),
                battery_level=np.random.uniform(0.5, 1.0),
            )

        for i in range(3):
            device_id = f"edge_{i}"
            self.register_device(
                device_id=device_id,
                device_type=EdgeDeviceType.EDGE_SERVER,
                compute_capacity=np.random.uniform(20, 50),
                memory_mb=np.random.uniform(8192, 32768),
                battery_level=1.0,
            )

    def register_device(
        self,
        device_id: str,
        device_type: EdgeDeviceType,
        compute_capacity: float,
        memory_mb: float,
        battery_level: float,
    ):
        """`device` 항목을 추가한다."""
        device = EdgeDevice(
            device_id=device_id,
            device_type=device_type,
            compute_capacity=compute_capacity,
            memory_mb=memory_mb,
            battery_level=battery_level,
            is_online=True,
        )
        self.devices[device_id] = device

    def submit_task(self, task: InferenceTask):
        """``submit_task`` 동작을 수행한다."""
        self.task_queue.append(task)
        self.task_queue.sort(key=lambda t: t.priority)

    def schedule_task(self, task_id: str) -> str | None:
        """`task` 작업을 계획한다."""
        for task in self.task_queue:
            if task.task_id == task_id:
                break
        else:
            return None

        target_device = self._select_device(task)

        if target_device:
            self.task_queue = [t for t in self.task_queue if t.task_id != task_id]
            self.active_tasks[task_id] = target_device.device_id
            return target_device.device_id

        return None

    def _select_device(self, task: InferenceTask) -> EdgeDevice | None:
        candidates = [d for d in self.devices.values() if d.is_online]

        if not candidates:
            return None

        if self.load_balancing == "memory_based":
            return max(candidates, key=lambda d: d.memory_mb)
        elif self.load_balancing == "compute_based":
            return max(candidates, key=lambda d: d.compute_capacity)
        else:
            return candidates[0]

    def complete_task(self, task_id: str):
        """``complete_task`` 동작을 수행한다."""
        if task_id in self.active_tasks:
            del self.active_tasks[task_id]

    def get_federation_status(self) -> dict[str, Any]:
        """`federation status` 정보를 조회한다."""
        return {
            "federation_id": self.federation_id,
            "total_devices": len(self.devices),
            "online_devices": sum(1 for d in self.devices.values() if d.is_online),
            "queued_tasks": len(self.task_queue),
            "active_tasks": len(self.active_tasks),
        }
