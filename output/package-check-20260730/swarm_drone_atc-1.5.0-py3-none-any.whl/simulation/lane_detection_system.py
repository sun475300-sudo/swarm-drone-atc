"""
Phase 434: Lane Detection System for Ground Navigation
"""

from dataclasses import dataclass

import numpy as np


@dataclass
class LanePoint:
    """``LanePoint`` 관련 기능을 제공한다."""
    x: float
    y: float
    confidence: float


@dataclass
class Lane:
    """``Lane`` 관련 기능을 제공한다."""
    lane_id: int
    points: list[LanePoint]
    lane_type: str


class LaneDetectionSystem:
    """``LaneDetectionSystem`` 역할을 담당한다."""
    def __init__(self, num_lanes: int = 4):
        """인스턴스를 초기화한다."""
        self.num_lanes = num_lanes

    def detect_lanes(self, image: np.ndarray) -> list[Lane]:
        """`lanes` 결과를 계산하거나 판정한다."""
        lanes = []

        for i in range(self.num_lanes):
            points = []
            for y in range(0, image.shape[0], 20):
                x = image.shape[1] // self.num_lanes * (i + 0.5)
                x += np.random.uniform(-20, 20)
                conf = np.random.uniform(0.6, 0.95)
                points.append(LanePoint(float(x), float(y), conf))

            lane_type = "solid" if i == 0 or i == self.num_lanes - 1 else "dashed"
            lanes.append(Lane(i, points, lane_type))

        return lanes

    def estimate_center_line(self, lanes: list[Lane]) -> list[LanePoint] | None:
        """`center line` 결과를 계산하거나 판정한다."""
        if not lanes:
            return None

        center_points = []
        for i in range(min(len(p) for p in [l.points for l in lanes])):
            xs = [l.points[i].x for l in lanes]
            center_x = np.mean(xs)
            conf = np.mean([l.points[i].confidence for l in lanes])
            center_points.append(LanePoint(center_x, lanes[0].points[i].y, conf))

        return center_points
