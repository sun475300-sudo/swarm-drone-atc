"""
Phase 428: Real-Time Stream Processor for Telemetry Data
"""

import time
from collections import deque
from collections.abc import Callable
from dataclasses import dataclass
from enum import Enum
from typing import Any


class StreamType(Enum):
    """``StreamType`` 관련 기능을 제공한다."""
    TELEMETRY = "telemetry"
    SENSOR = "sensor"
    EVENT = "event"
    COMMAND = "command"


@dataclass
class StreamEvent:
    """``StreamEvent`` 데이터를 표현한다."""
    event_id: str
    stream_type: StreamType
    data: dict[str, Any]
    timestamp: float
    drone_id: str


@dataclass
class ProcessingResult:
    """``ProcessingResult`` 데이터를 표현한다."""
    event_id: str
    processed: bool
    output: Any
    latency_ms: float


class RealTimeStreamProcessor:
    """``RealTimeStreamProcessor`` 관련 기능을 제공한다."""
    def __init__(self, buffer_size: int = 1000, num_workers: int = 4):
        """인스턴스를 초기화한다."""
        self.buffer_size = buffer_size
        self.num_workers = num_workers

        self.buffers: dict[StreamType, deque] = {
            st: deque(maxlen=buffer_size) for st in StreamType
        }

        self.processors: dict[StreamType, Callable] = {}
        self.windowed_aggregates: dict[str, float] = {}

        self.metrics = {
            "events_processed": 0,
            "events_dropped": 0,
            "avg_latency_ms": 0.0,
        }

    def register_processor(self, stream_type: StreamType, processor: Callable):
        """`processor` 항목을 추가한다."""
        self.processors[stream_type] = processor

    def ingest(self, event: StreamEvent):
        """``ingest`` 동작을 수행한다."""
        self.buffers[event.stream_type].append(event)

    def process_stream(self, stream_type: StreamType) -> list[ProcessingResult]:
        """`stream` 처리 로직을 수행한다."""
        results = []

        buffer = self.buffers[stream_type]

        while buffer:
            event = buffer.popleft()

            start_time = time.time()

            if stream_type in self.processors:
                output = self.processors[stream_type](event.data)
            else:
                output = self._default_process(event.data)

            latency = (time.time() - start_time) * 1000

            result = ProcessingResult(
                event_id=event.event_id,
                processed=True,
                output=output,
                latency_ms=latency,
            )

            results.append(result)

            self.metrics["events_processed"] += 1
            self.metrics["avg_latency_ms"] = (
                self.metrics["avg_latency_ms"] * 0.99 + latency * 0.01
            )

        return results

    def _default_process(self, data: dict) -> dict:
        return {"status": "processed", "data": data}

    def compute_window_aggregate(self, key: str, window_sec: float = 60.0) -> float:
        """`window aggregate` 값을 계산한다."""
        now = time.time()

        total = 0.0
        count = 0

        for buffer in self.buffers.values():
            for event in buffer:
                if now - event.timestamp <= window_sec:
                    total += event.data.get(key, 0)
                    count += 1

        return total / count if count > 0 else 0.0

    def get_metrics(self) -> dict[str, Any]:
        """`metrics` 정보를 조회한다."""
        return {
            "events_processed": self.metrics["events_processed"],
            "events_dropped": self.metrics["events_dropped"],
            "avg_latency_ms": self.metrics["avg_latency_ms"],
            "buffer_sizes": {st.value: len(buf) for st, buf in self.buffers.items()},
        }
